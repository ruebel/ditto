var UserProfileModel = function(cnf){
    this.username = cnf.username,
    this.firstName = cnf.firstName,
    this.lastName = cnf.lastName
};

module.exports = UserProfileModel;